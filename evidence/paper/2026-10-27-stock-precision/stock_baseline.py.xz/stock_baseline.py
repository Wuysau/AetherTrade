"""Run new composition tests against committed generators without editing files."""
import importlib
from pathlib import Path
import subprocess
import sys

import pytest

for name, path in (
    ('trading_system.execution.children', 'src/trading_system/execution/children.py'),
    ('trading_system.protection.manager', 'src/trading_system/protection/manager.py'),
):
    module = importlib.import_module(name)
    source = subprocess.check_output(['git', 'show', '6b2c770:' + path], text=True)
    exec(compile(source, str(Path(path).resolve()), 'exec'), module.__dict__)
raise SystemExit(pytest.main(['-q', 'tests/qualification/test_stock_generated_commands.py']))
