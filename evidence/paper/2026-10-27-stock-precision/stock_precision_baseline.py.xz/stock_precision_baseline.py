"""Exercise committed precision-bug sources in memory; do not edit source files."""
import importlib
from pathlib import Path
import subprocess
import pytest
for name, path in (
    ('trading_system.protection.native', 'src/trading_system/protection/native.py'),
    ('trading_system.protection.manager', 'src/trading_system/protection/manager.py'),
    ('trading_system.protection.exit', 'src/trading_system/protection/exit.py'),
):
    module = importlib.import_module(name)
    source = subprocess.check_output(['git', 'show', 'ee346af:' + path], text=True)
    exec(compile(source, str(Path(path).resolve()), 'exec'), module.__dict__)
raise SystemExit(pytest.main(['-q', 'tests/qualification/test_stock_generated_commands.py',
                             'tests/integration/test_protection_quantity_precision.py']))
