import json
import os
from pathlib import Path
import psycopg

snapshots = {}
for ip in ('07', '10'):
    with psycopg.connect(os.environ[f'IP{ip}_DATABASE_DSN']) as conn:
        conn.execute('SET ROLE ledger_owner')
        rows = conn.execute('SELECT a.scope_id,a.command_id,a.command_payload,a.outcome,'
            'c.sequence,c.payload,(SELECT jsonb_agg(jsonb_build_object('
            "'reservation_initial',r.payload,'projection',p.payload)) FROM ledger.reservations r "
            'LEFT JOIN LATERAL (SELECT payload FROM ledger.audit_events '
            "WHERE scope_id=r.scope_id AND record_id='ip07:reservation:' || r.record_id "
            'ORDER BY sequence DESC LIMIT 1) p ON true '
            "WHERE r.scope_id=a.scope_id AND r.payload->>'intent_id'=a.command_payload->>'intent_id') "
            'FROM ledger.command_aborts a LEFT JOIN LATERAL '
            '(SELECT sequence,payload FROM ledger.commands WHERE scope_id=a.scope_id '
            'AND record_id=a.command_id ORDER BY sequence DESC LIMIT 1) c ON true '
            'ORDER BY a.command_id').fetchall()
        snapshots[ip] = [dict(zip(('scope_id','command_id','initial_command','authoritative_abort',
            'raw_command_sequence','raw_command','reservation_ledger'), row)) for row in rows]
Path('/evidence/abortguard-ledger-snapshot.json').write_text(json.dumps(snapshots,indent=2)+'\n')
print({ip: len(rows) for ip,rows in snapshots.items()})
